package utils;

import models.DaftarPaket;
import models.User;

public class ConstUtil {
    
    public static final String DRIVER_MYSQL = "com.mysql.jdbc.Driver";
    public static User auth = null;
    public static DaftarPaket konpak = null;
    public static int targetTag = 0;
    
}